package com.example.dextest;

import android.content.Context;
import android.widget.Button;

public class Test2 extends Button {

	public Test2(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		setText("Test2 button");
	}

}
