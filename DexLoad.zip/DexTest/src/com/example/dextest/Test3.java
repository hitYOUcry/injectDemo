package com.example.dextest;

import android.util.Log;

public class Test3 {
	public void test() {
		Log.i("Test3", "Test Dex!!!");
	}
	public int add(int a,int b)
	{
		return a+b;
	}
}
